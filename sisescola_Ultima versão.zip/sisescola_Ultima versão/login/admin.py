from django.contrib import admin

from .models import CadastroLogin


class CadastroLoginAdmin(admin.ModelAdmin):
	list_display = ['nome','nip','criacao','atualicacao'] #cria no template do adm um display de seleção com o nome e o nip
	search_fields = ['nome','nip']	#cria uma opção de busca atraves do nome ou do nip

admin.site.register(CadastroLogin,CadastroLoginAdmin)
