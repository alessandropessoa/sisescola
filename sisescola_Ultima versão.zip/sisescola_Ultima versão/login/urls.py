#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.conf.urls import url
from . import views
from django.contrib.auth import views as contas



urlpatterns = [
	url(r'^$',contas.login,{'template_name':'login/index.html'},name='login'),
	url(r'^logout/$',contas.logout,{'template_name':'login/sair.html'},name='logout'),
	
	url(r'^opcoes/$',views.opcoes,name='opcoes'),
    
]

