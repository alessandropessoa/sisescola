from django.shortcuts import render
from django.http import HttpResponse
from .models import CadastroLogin
from .forms import CadastroLoginForm


def login(request):
    
    login = CadastroLogin()
    context = {}
    form = CadastroLoginForm()    
    if request.method == 'POST':
        form = CadastroLoginForm(request.POST)
        
        if form.is_valid():		
            context['is_valid'] = True
            form = CadastroLoginForm()				
    else:
	    	
	    context['form'] = form
         
    html ='login/index.html'
         
    return render(request, html, context)


def opcoes(request):
    html ='login/opcoes.html'
    return render(request,html)
