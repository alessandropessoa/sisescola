from django.db import models


class CadastroLogin(models.Model):
	
	nip = models.CharField('NIP',max_length=20)
	nome = models.CharField('NOME',max_length=50)
	senha = models.CharField('SENHA',max_length=20)
	criacao = models.DateTimeField('Criado em:',auto_now_add=True)
	atualicacao = models.DateTimeField('Atualizado em',auto_now=True)
	imagem = models.ImageField(upload_to='img', verbose_name='IMAGEM',null=True,blank=True)

	def __str__(self):
		return self.nome
		
	class Meta:
		
		verbose_name = 'USUARIO CADASTRADO'
		verbose_name_plural = 'USUARIOS CADASTRADOS'
		ordering = ['nome']
		
