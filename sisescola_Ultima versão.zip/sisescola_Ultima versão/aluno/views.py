from django.shortcuts import render
from django.http import HttpResponse
from .models import cadastroAluno




def cadAlunos(request):
	

	contexto	= {}
	aluno =''
	busca	= request.POST.get('btn-buscar')
	todos	= request.POST.get('btn-todos')
	
	
	if busca == 'buscar':
		filtro	= request.POST.get('filtro')
		selBusca	= request.POST.get('selBusca')
		
		contexto['valBusca']	=	True
		
		if selBusca == 'NIP':
			aluno	= cadastroAluno.objects.filter(nip= filtro)
			print(aluno)
			
		elif selBusca == 'NOME':
			aluno	= cadastroAluno.objects.filter(nome= filtro)
			
		elif selBusca == 'RG':
			aluno	= cadastroAluno.objects.filter(rg= filtro)
			
		elif selBusca == 'PASSAPORTE':
			aluno	= cadastroAluno.objects.filter(passaporte= filtro)
			

		
	elif todos == 'todos':
		print('chamou todos')
		contexto['valBusca']	=	False
		aluno = cadastroAluno.objects.all()
		
	else:
		contexto['valBusca']	=	False
		aluno = cadastroAluno.objects.all()

	selecExc	=	request.POST.getlist('selecao')	
	btnExc	=	request.POST.get('btnExc',[])

	if btnExc == 'exclui':
		print('dentro de exclui')
		if not selecExc == []:
			for x in selecExc:
				objExc	=	x.split('/')[0]
				
				cadastroAluno.objects.filter(id = objExc).delete()		
		
			
			
	contexto = {
				'aluno' : aluno}				
	
	html = "aluno/cadAlunos.html"
	return render(request, html,contexto)
	
	
def alunos(request):
	
	
	contexto ={}
	html = "aluno/aluno.html"
	
	cadAl = cadastroAluno()

	
	if request.method == "POST":
		
		
		cadAl.militarCivil		= request.POST.get('militarCivil','').upper()
		cadAl.nome				= request.POST.get('nome','').upper()
		cadAl.nip				= request.POST.get('nip',[])
		cadAl.postoGrad			= request.POST.get('postoGrad',[])
		cadAl.nomeGuerra		= request.POST.get('nomeGuerra',[])
		cadAl.om				= request.POST.get('om',[])
		cadAl.cmdOm				= request.POST.get('cmdOm',[]) 
		cadAl.rg				= request.POST.get('rg',[])
		cadAl.orgao				= request.POST.get('orgao',[])
		cadAl.cpf				= request.POST.get('cpf',[])
		cadAl.tipoSanguineo		= request.POST.get('tipoSanguineo',[])
		cadAl.passaporte		= request.POST.get('passaporte','NÃO INFORMADO')
		cadAl.tel01				= request.POST.get('tel01',[])
		cadAl.tel02				= request.POST.get('tel02','NÃO INFORMADO')
		cadAl.dataNsc			= request.POST.get('dataNsc',[])
		cadAl.cidadeNsc			= request.POST.get('cidadeNsc',[])
		cadAl.ufNsc				= request.POST.get('ufNsc',[])
		cadAl.paisNsc			= request.POST.get('paisNsc',[])
		cadAl.pai				= request.POST.get('pai',[])
		cadAl.mae				= request.POST.get('mae',[])
		cadAl.cep				= request.POST.get('cep','NÃO INFORMADO')
		cadAl.endereco			= request.POST.get('endereco',[])
		cadAl.numero			= request.POST.get('numero',[])
		cadAl.complemento		= request.POST.get('complemento','NÃO INFORMADO')
		cadAl.bairro			= request.POST.get('bairro',[])
		cadAl.cidade			= request.POST.get('cidade',[])
		cadAl.uf				= request.POST.get('uf',[])
		cadAl.pais				= request.POST.get('pais',[])
		cadAl.comunicaAcid		= request.POST.get('comunicaAcid',[])
		cadAl.parentesco		= request.POST.get('parentesco',[])
		cadAl.acdTel			= request.POST.get('acdTel',[])
		cadAl.acdCep			= request.POST.get('acdCep','NÃO INFORMADO')
		cadAl.acdEnd			= request.POST.get('acdEnd',[])
		cadAl.acdnumero			= request.POST.get('acdnumero	',[])
		cadAl.acdcomplemento	= request.POST.get('acdcomplemento','NÃO INFORMADO')
		cadAl.acdbairro			= request.POST.get('acdbairro',[])
		cadAl.acdcidade			= request.POST.get('acdcidade	',[])
		cadAl.acduf				= request.POST.get('acduf',[])
		cadAl.acdpais			= request.POST.get('paisacd',[])
		cadAl.cepTrab			= request.POST.get('cepTrab','NÃO INFORMADO')
		cadAl.enderecoTrab		= request.POST.get('enderecoTrab',[])
		cadAl.numeroTrab    	= request.POST.get('numeroTrab ',[])
		cadAl.complementoTrab	= request.POST.get('complementoTrab','NÃO INFORMADO')
		cadAl.cidadeTrab 		= request.POST.get('cidadeTrab ',[])
		cadAl.bairroTrab		= request.POST.get('bairroTrab',[])
		cadAl.cidadeTrab		= request.POST.get('cidadeTrab',[])
		cadAl.ufTrab			= request.POST.get('ufTrab',[])
		cadAl.paisTrab			= request.POST.get('paisTrab',[])
		cadAl.observacao		= request.POST.get('observ','')
		cadAl.save()
		
		print('dados salvo com sucesso')


	return render(request, html,contexto)
	
def teste(request):
	contexto={}
	html = "aluno/teste.html"
	return render(request, html,contexto)

