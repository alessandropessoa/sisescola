from django.contrib import admin

from .models import cadastroAluno


class cadastroAlunoAdmin(admin.ModelAdmin):
	list_display = ['nome','nip'] #cria no template do adm um display de seleção com o nome e o nip
	search_fields = ['nome','nip']#cria uma opção de busca atraves do nome ou do nip



admin.site.register(cadastroAluno,cadastroAlunoAdmin)

