from django.db import models as md
from django.forms import ModelForm
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse


class cadastroAluno(md.Model):
	
	
	tip_sang = (("A +","A +"),
				("A -","A -"),
				("B +","B +"),
				("B -","B -"),
				("O +","O +"),
				("O -","O -"),
				("AB +","AB +"),
				("AB -","AB -")
				)

	
	foto 			= md.ImageField(upload_to ='media',verbose_name='Foto do Aluno', null=True, blank=True)
	militarCivil	= md.CharField("Militar/civil",max_length=10 , blank=True)
	nome  		  	= md.CharField("Nome",max_length=50 , blank=True)
	nip   		  	= md.CharField("NIP",max_length=20 , blank=True, null=True)
	postoGrad		= md.CharField("Posto/Graduação", max_length=20 , blank=True)
	nomeGuerra		= md.CharField("Nome de Guerra", max_length=20 , blank=True)
	om				= md.CharField("Nome da OM", max_length=40 , blank=True)
	cmdOm			= md.CharField("Comandante da OM", max_length=50 , blank=True)
	rg    		  	= md.CharField("RG",max_length=20 , blank=True)
	orgao 		  	= md.CharField("ORGÂO",max_length=20 , blank=True)
	cpf	  		  	= md.CharField("CPF",max_length=20 , blank=True)
	tipoSanguineo 	= md.CharField("Tipo Sanguineo", choices = tip_sang, default="O-", max_length=3)
	passaporte 	  	= md.CharField("Passaporte",max_length=20 , blank=True)
	tel01 		 	= md.CharField("Telefone 01", max_length=15 , blank=True)
	tel02 		  	= md.CharField("Telefone 02", max_length=15 , blank=True)
	dataNsc		 	= md.CharField("Data de Nascimento", max_length=10 , blank=True)
	cidadeNsc	  	= md.CharField("Cidade de Nascimento", max_length=10 , blank=True)
	ufNsc		  	= md.CharField("Estado de Nascimento", max_length=10 , blank=True)
	paisNsc			= md.CharField("País de Nascimento ", max_length=20 , blank=True)
	pai			  	= md.CharField("Nome do Pai", max_length=30 , blank=True)
	mae			  	= md.CharField("Nome do Mãe", max_length=30 , blank=True)
	cep			  	= md.CharField("CEP", max_length=10 , blank=True)
	endereco	  	= md.CharField("Endereço", max_length=50 , blank=True)
	numero 		  	= md.CharField("Numero", max_length=5 , blank=True)
	complemento	  	= md.CharField("Complemento", max_length=40 , blank=True)
	bairro		  	= md.CharField("Bairro", max_length=20 , blank=True)
	cidade		  	= md.CharField("Cidade", max_length=20 , blank=True)
	uf			  	= md.CharField("Estado", max_length=10 , blank=True)
	pais			= md.CharField("País", max_length=20 , blank=True)
	comunicaAcid  	= md.CharField("Comunicar Em caso de Acidente", max_length=40 , blank=True)
	parentesco	    = md.CharField("Parentesco ", max_length=10 , blank=True)
	acdTel		 	= md.CharField("Telefone caso de Acidente", max_length=15 , blank=True)
	acdCep		 	= md.CharField("CEP do Contato de Acidente", max_length=10 , blank=True)
	acdEnd		 	= md.CharField("Endereço do Contato de Acidente", max_length=50 , blank=True)
	acdnumero 		= md.CharField("Numero do Endereço do Contato de Acidente", max_length=5 , blank=True)
	acdcomplemento	= md.CharField("Complemento do Endereço do Contato de acidente", max_length=40 , blank=True)
	acdbairro		= md.CharField("Bairro do Contato de acidente", max_length=50 , blank=True)
	acdcidade		= md.CharField("Cidade do Contato de acidente", max_length=50 , blank=True)
	acduf			= md.CharField("Estado do Contato de acidente", max_length=10 , blank=True)
	acdpais			= md.CharField("PAÌS do Contato de acidente", max_length=20 , blank=True)
	cepTrab			= md.CharField("CEP do Local de Trabalho ", max_length=10 , blank=True)
	enderecoTrab	= md.CharField("Endereço do Local de Trabalho", max_length=50 , blank=True)
	numeroTrab	 	= md.CharField("Numero do Endereço Local de Trabalho", max_length=5 , blank=True)
	complementoTrab	= md.CharField("Complmento do Endereço do Local de Trabalho", max_length=40 , blank=True)
	bairroTrab		= md.CharField("Bairro do Local de Trabalho", max_length=20 , blank=True)
	cidadeTrab		= md.CharField("Cidade do Local de Trabalho", max_length=20 , blank=True)
	ufTrab			= md.CharField("Estado do Local de Trabalho", max_length=10 , blank=True)
	paisTrab		= md.CharField("PAIS do Local de Trabalho", max_length=20 , blank=True)
	observacao		= md.TextField("Observação", max_length=50 , blank=True)
	
	

	
	def __str__(self):
		return self.nome
		

		
	class Meta:
		
		verbose_name = 'CADASTRO DE ALUNO'
		verbose_name_plural = 'CADASTRO DE ALUNOS'
		ordering = ['nome',"nip"]
		

	
