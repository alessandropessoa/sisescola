#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.conf.urls import url
from . import views



urlpatterns = [
	url(r'^cadAlunos/$',views.cadAlunos,name='cadAlunos'),
	url(r'^cadAlunos/alunos/$',views.alunos,name='alunos'),
	url(r'^cadAlunos/teste/$',views.teste,name='teste')
	
    
]

