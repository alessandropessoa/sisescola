#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django import forms


class CadastroLoginForm(forms.Form):
	nip = forms.CharField(label='NIP',max_length=20)
	senha = forms.CharField(label='SENHA',max_length=20)
    

