from django.shortcuts import render
from django.http import HttpResponse



def controle_cursos(request):
         
    html ='controleCurso/controle_curso.html'
         
    return render(request, html)
