from django.apps import AppConfig


class ControleCursoConfig(AppConfig):
    name = 'controle_curso'
