from django.contrib import admin

from .models import Escolas, Cursos,CursosDisciplinas, CursosDisciplinasAvaliacao


class EscolasAdmin(admin.ModelAdmin):
	list_display = ['escola','cod'] 
	search_fields = ['escola','cod']
admin.site.register(Escolas,EscolasAdmin)

class CursosAdmin(admin.ModelAdmin):
	list_display = ['curso','titulo'] 
	search_fields = ['curso']

admin.site.register(Cursos,CursosAdmin)


class CursosDisciplinasAdmin(admin.ModelAdmin):
	list_display = ['disciplina','escolas'] 
	search_fields = ['disciplina']

admin.site.register(CursosDisciplinas,CursosDisciplinasAdmin)


class CursosDisciplinasAvaliacaoAdmin(admin.ModelAdmin):
	list_display = ['avaliacao'] 
	search_fields = ['avaliacao']

admin.site.register(CursosDisciplinasAvaliacao,CursosDisciplinasAvaliacaoAdmin)

