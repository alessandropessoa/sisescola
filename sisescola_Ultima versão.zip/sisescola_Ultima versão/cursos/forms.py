#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django import forms
from django.forms import ModelForm
from .models import CursosDisciplinasAvaliacao, CursosDisciplinas


class CursosDisciplinasAvaliacaoModelForm(ModelForm):
			
	class Meta:
		model	= CursosDisciplinasAvaliacao
		fields	= ('__all__')



class CursosDisciplinasModelForm(ModelForm):
	class Meta:
		model 	= CursosDisciplinas
		fields 	= ('__all__')

    

