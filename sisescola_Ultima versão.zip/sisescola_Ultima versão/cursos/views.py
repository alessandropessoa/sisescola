from django.shortcuts import render
from django.http import HttpResponse
from .forms import CursosDisciplinasAvaliacaoModelForm, CursosDisciplinasModelForm



def cursos(request):
    contexto	=	{}  
    html 		=	'cursos/cursos.html'
         
    return render(request, html, contexto)
    
def cursosTeste(request):
	html	= 'cursos/teste.html'
	contexto = {
		'teste':CursosDisciplinasAvaliacaoModelForm(),
		'teste2': CursosDisciplinasModelForm()
				}
	return render(request, html,contexto)
