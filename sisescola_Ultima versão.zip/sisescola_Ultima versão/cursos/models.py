from django.db import models as md

class Escolas(md.Model):
	cod 	= md.IntegerField(verbose_name="CODIGO DA ESCOLA",null=True,blank=True) 
	escola	= md.CharField("Escola", max_length=20,null=True,blank=True)
	
	def __str__(self):
		return self.escola

	class Meta:
		verbose_name		= "ESCOLA"
		verbose_name_plural = "ESCOLAS"

class Cursos(md.Model):
	escolas     	= md.ForeignKey(Escolas,null=True,blank=True)
	
	codEscola 		= md.IntegerField(verbose_name="CODIGO DA DISCIPLINA")
	
	titulo 			= md.CharField("TITULO", max_length=100)
	
	curso			= md.CharField("SIGLA", max_length=20)	
	
	proposito		= md.TextField(verbose_name="PROPOSITO")
	tipoENS			= md.CharField("TIPO DE ENSINO", max_length=30)	
	reqMat			= md.TextField(verbose_name="REQUISITO PARA MATRICULA")
	duracao			= md.CharField("DURACAO", max_length=20)
	custo			= md.CharField("CUSTO", max_length=30)
	
	minAlunos		= md.IntegerField(verbose_name="MINIMO DE ALUNOS",blank=True,null=True)
	maxAlunos		= md.IntegerField(verbose_name="MAXIMO DE ALUNOS",blank=True,null=True)	
	
	atoCriacao		= md.CharField("ATO DE CRIAÇÃO", max_length=30)
	
	anexoJ			= md.BooleanField("ANEXO 'J'", default=False)
	iSaude			= md.BooleanField("INSPEÇÃO DE SAUDE", default=True)
	avPsi			= md.BooleanField("AVALIAÇÃO PSICOLOGICA", default=True)
	camara			= md.BooleanField("TESTE DE CAMARA", default=False)
	testeFisico		= md.BooleanField("AVALIAÇÃO FISICA", default=False)
	
	corridaDist		= md.CharField(verbose_name="DISTANCIA CORRIDA EM METROS", max_length=20,blank=True,null=True)
	corridatTempo	= md.CharField(verbose_name="Tempo da CORRIDA EM MINUTOS", max_length=20,blank=True,null=True)
	natDist			= md.CharField("DISTANCIA DA NATAÇÃO 1 (METROS)", max_length=20,blank=True,null=True)
	natTempo		= md.CharField("TEMPO DA NATAÇÃO 1", max_length=20,blank=True,null=True)
	nat2Dist		= md.CharField("DISTANCIA DA NATAÇÃO 2 (METROS) ", max_length=20,blank=True,null=True)
	nat2Tempo		= md.CharField("TEMPO DA NATAÇÃO 2", max_length=20,blank=True,null=True)
	
	agachaTempo		= md.CharField("TEMPO MAX. DO AGACHAMENTO2", max_length=20,blank=True,null=True)
	agachaMin		= md.CharField("TEMPO MIN. DO AGACHAMENTO2", max_length=20,blank=True,null=True)
	apneiaDinamica	= md.CharField("APNEIA DINÂMICA (METROS) ", max_length=20,blank=True,null=True)
	apneiaEstatica	= md.CharField("APNEIA ESTATICA (TEMPO) ", max_length=20,blank=True,null=True)
	cabo			= md.CharField("ALTURA DO CABO (METROS) ", max_length=20,blank=True,null=True)
	fxSolo			= md.CharField("FLEXÃO NO SOLO (REPETIÇÕES) ", max_length=20,blank=True,null=True)
	fxBarra			= md.CharField("FLEXÃO NO BARRA (REPETIÇÕES) ", max_length=20,blank=True,null=True)
	
	def __str__(self):
		return self.curso
		
	class Meta:
		verbose_name		= "CURSO"
		verbose_name_plural = "CURSOS"



class CursosDisciplinas(md.Model):
	cursos = md.ForeignKey(Cursos)
	# o cmpo 'curso' ve da relação com 'Curos'
	
	escolas = md.ForeignKey(Escolas)
	#o campo 'cod' vem da relação com 'escolas'
	
	codDisciplina		= md.CharField("CODIGO DA DISCIPLINA ", max_length=20)
	
	disciplina			= md.CharField("NOME DA DISCIPLINA ", max_length=100)
	abrevDisciplina		= md.SlugField(verbose_name="ABREVIATURA DA DISCIPLINA ", max_length=20)
	cargaHoraria		= md.CharField("CARGA HORARIA DA DISCIPLINA ", max_length=20)
	formula				= md.CharField("FORMULA DA DISCIPLINA ", max_length=40)
	
	def __str__(self):
		return self.disciplina
	
	class Meta:
		verbose_name		= "DISCIPLINA DO CURSO"
		verbose_name_plural = "DISCIPLINAS DOS CURSOS"
	
class CursosDisciplinasAvaliacao(md.Model):
	CursosDisciplinas 	= md.ForeignKey(CursosDisciplinas)
	avaliacao			= md.CharField(verbose_name="AVALIAÇÃO ", max_length=20)
	
	def __str__(self):
		return self.avaliacao
		
	class Meta:
		verbose_name		= "AVALIAÇÃO"
		verbose_name_plural = "AVALIAÇÕES"
	
	
	

