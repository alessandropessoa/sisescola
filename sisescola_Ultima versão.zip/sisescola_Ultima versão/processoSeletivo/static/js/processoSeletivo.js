function adicionaVoluntario(){
	window.open('adcionaVoluntario/',name='_blank',"width=950px,height=500px,left=250px,top=100px");
	
	}

function cadVol(){
	
	window.open('cadVoluntarios/',name='_blank',"width=580px,height=300px,left=350px,top=250px");
	
	}
