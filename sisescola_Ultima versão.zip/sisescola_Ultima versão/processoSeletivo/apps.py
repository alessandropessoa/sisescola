from django.apps import AppConfig


class ProcessoseletivoConfig(AppConfig):
    name = 'processoSeletivo'
