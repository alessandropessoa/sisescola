from django.shortcuts import render


def processoSeletivo(request):
	html ='processoSeletivo/processoSeletivo.html'
	return render(request,html)

def adicionaVoluntario(request):
	html='processoSeletivo/adicionaVoluntario.html'
	return render(request, html)

def cadVoluntarios(request):
	html = 'processoSeletivo/cadVol.html'
	return render(request, html)
