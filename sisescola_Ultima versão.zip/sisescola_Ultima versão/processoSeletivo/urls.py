#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.conf.urls import url
from . import views


urlpatterns = [

	url(r'^processoSeletivo/$',views.processoSeletivo,name='Psel'),
	url(r'^processoSeletivo/adcionaVoluntario/$',views.adicionaVoluntario, name='adicVol'),
	url(r'^processoSeletivo/adcionaVoluntario/cadVoluntarios/$', views.cadVoluntarios, name='cadVol')
    
]

